from django.urls import path
from . import views

urlpatterns= [
    path('', views.HOME, name="home"),
    path('update_task/<str:pk>/',views.Update, name="update_task"),
    path('del/<str:pk>/',views.Delete, name="del"),
]