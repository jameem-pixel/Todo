from django import forms
from django.forms import ModelForm, fields
from django.forms.widgets import TextInput
from .models import *

class TaskForm(forms.ModelForm):
    name = forms.CharField(widget=TextInput(attrs={'placeholder':'Add new task here..'})) 
    class Meta:
        model = Task
        fields = '__all__'