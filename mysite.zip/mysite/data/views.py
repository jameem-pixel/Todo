from data.forms import TaskForm
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *

def HOME(request):
    tasks = Task.objects.all()
    form = TaskForm()
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect("/")    
    context = {'tasks':tasks, 'form':form}
    return render(request, 'data/home.html',context)

def Update(request, pk):
    tasks =Task.objects.get( id = pk)
    form = TaskForm(instance=tasks)
    context = {'tasks':tasks, 'form':form}
    
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=tasks)
        if form.is_valid():
            form.save()
        return redirect("/")    
    return render(request, 'data/update_task.html', context)
def Delete(request, pk):
    item = Task.objects.get(id = pk)
    context = {'item':item}
    if request.method == 'POST':
        item.delete()
        return redirect("/")    
    return render (request,'data/del.html', context)